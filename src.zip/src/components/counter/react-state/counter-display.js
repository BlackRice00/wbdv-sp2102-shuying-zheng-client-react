import React from 'react'

const CounterDisplay = ({count}) =>
    <h1>
        Count: {count}
    </h1>

export default CounterDisplay