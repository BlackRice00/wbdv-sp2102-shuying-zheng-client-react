import React from 'react'

const CounterDown = ({down}) =>
    <button onClick={down}>
        Down
    </button>

export default CounterDown