import React from 'react'

const CounterUp = ({up}) =>
    <button onClick={up}>
        Up
    </button>

export default CounterUp