import React, {useEffect} from 'react'
import {connect} from 'react-redux'
import EditableItem from "./editable-item";
import {useParams} from "react-router-dom";
import lessonService from '../services/lesson-service'
import moduleService from "../services/module-service";

const LessonTabs = (
    {
        lessons=[
            // {_id: "123", title: "Lesson A"},
            // {_id: "124", title: "Lesson B"},
            // {_id: "125", title: "Lesson C"}
        ],
        findLessonsForModule,
        createLessonForModule,
        deleteLesson
    }
) =>{
    const {courseId, moduleId, lessonId} = useParams();
    useEffect(() => {
        if(moduleId !== "undefined" && typeof moduleId !== "undefined") {
            findLessonsForModule(moduleId)
        }
    }, [moduleId])
    return (<div>
        <h2>Lessons</h2>
        <ul className="nav nav-pills">
            {
                lessons.map(lesson =>
                    <li className="nav-item">
                        <EditableItem
                            active={lesson._id === lessonId}
                            deleteItem={deleteLesson}
                            to={`/courses/editor/${courseId}/${moduleId}/${lesson._id}`}
                            item={lesson}/>
                    </li>
                )
            }
            <li>
                <i onClick={() => createLessonForModule(moduleId)} className="fas fa-plus"></i>
            </li>
        </ul>
    </div>)
}


const stpm = (state) => ({
    lessons: state.lessonReducer.lessons
})
const dtpm = (dispatch) => ({
    findLessonsForModule: (moduleId) => {
        console.log(moduleId)
        lessonService.findLessonsForModule(moduleId)
            .then(lessons => dispatch({
                type: "FIND_LESSONS",
                lessons: lessons
            }))
    },
    createLessonForModule: (moduleId) => {
        console.log("CREATE LESSON" + moduleId)
        lessonService.createLessonForModule(moduleId, {title: "New Lesson"})
            .then(lesson => dispatch({
                type: "CREATE_LESSON",
                lesson
            }))
    },
    deleteLesson: (module, lesson) =>
        moduleService.deleteLesson(module._id, lesson._id)
            .then(status =>dispatch({
                type: "DELETE_LESSON",
                lessonToDelete: lesson
            }))
})

export default connect(stpm, dtpm)(LessonTabs)